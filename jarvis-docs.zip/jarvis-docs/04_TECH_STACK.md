# 04 — Technology Stack

Each choice states *why*, not just *what*, per the constitution's ban on cargo-culting popular
tech.

## Language & UI

- **Kotlin** — required for modern Android; first-class coroutine support is essential for a
  system with many concurrent async operations (voice streaming, tool execution, network calls).
- **Jetpack Compose** — declarative UI matches the state-machine-driven nature of the JARVIS UI
  (listening/thinking/speaking/idle states drive UI directly from state, not imperative view
  mutation); needed for the custom animated activation sequence.

## Architecture Components

- **Coroutines + Flow** — the entire pipeline (audio → STT → planner → tool executor → TTS) is a
  chain of asynchronous, cancellable, backpressure-aware streams. Flow models this cleanly;
  callbacks would not.
- **Dependency Injection (Hilt)** — the tool registry, AI client, and Android integration layers
  need to be swappable/mockable for testing (e.g., inject a fake AI client in unit tests, a fake
  AccessibilityService bridge in agent-loop tests).
- **WorkManager** — for deferred, guaranteed-eventually work that does not need to run instantly
  (e.g., scheduled reminders that must survive reboot), not for anything requiring low latency.
- **Foreground Services** — required for anything that must keep running while the user is in
  another app: an active voice session, an active wake-word listener (where the Assistant role
  makes that legitimate), an in-progress multi-step task. Each foreground service declares the
  correct Android 14+ foreground service type (`microphone`, `mediaPlayback`, etc.) per
  `06_ANDROID_CAPABILITIES.md`.
- **DataStore (Proto)** — structured, typed local settings and preference storage, replacing
  SharedPreferences; used for user-controlled settings (address-as-"Sir" toggle, memory
  on/off, confirmation policy).
- **Room** — local database for anything relational and queryable: task history, memory records,
  conversation summaries. Not used until a version actually needs persisted structured data
  (V11 Memory), per Rule 5 (least privilege / least footprint by default).

## AI & Voice

- **Gemini API** (cloud) — primary reasoning layer: NLU, planning, tool selection, response
  generation. Accessed via a thin `AiClient` interface so the concrete provider is swappable
  (`ADR-002`), never called directly from UI or tool-execution code.
- **Android SpeechRecognizer / on-device recognition** where available for STT; cloud STT as a
  fallback/quality option, gated by a user setting given the privacy implications of streaming
  raw audio off-device.
- **Android TextToSpeech (system engine)** as the default TTS; evaluate a higher-quality
  neural TTS (cloud or on-device) once the baseline pipeline is proven in V3, tracked as an ADR
  if adopted, because it changes the offline story documented in `11_MEMORY... / OFFLINE`.
- **Wake-word**: local keyword-spotting engine (e.g., an on-device DSP/keyword-spotting library)
  evaluated in `09_VOICE_AND_WAKE_WORD.md` against Android's `AlwaysOnHotwordDetector` /
  Assistant-role hotword path; the two are not the same thing and the doc is explicit about which
  is realistic for a third-party app without OEM hotword partnership.

## Android Integration

- **AccessibilityService** — for UI observation/automation, gated heavily by Play policy (see
  `10_ACCESSIBILITY_ARCHITECTURE.md`); this is the highest-risk dependency in the stack and is
  isolated behind a narrow interface so it can be constrained, audited, or replaced without
  touching the planner.
- **RoleManager / VoiceInteractionService** — for the Assistant role, evaluated but not assumed
  achievable at launch (holding the Assistant role competes with Google Assistant/Gemini as the
  device default and has historically had reliability issues surviving app reinstalls).
- **MediaSessionManager / NotificationListenerService / AlarmManager / Intents** — the
  well-supported, low-risk half of device integration; prioritized in V6 before any Accessibility
  work begins.

## Testing

- **JUnit5 + MockK** for unit tests (Kotlin-idiomatic mocking).
- **Turbine** for testing Flow emissions from the async pipeline.
- **Espresso + Compose UI Testing** for UI tests.
- **UI Automator** for instrumentation tests that need to interact with other apps or system UI
  (necessary for testing V6+ device-action tools against real launched apps).
- **Robolectric** for fast JVM-level Android framework tests where a full emulator is unnecessary.

## Backend

No backend service is introduced before it is needed. V1–V9 do not require one: Gemini API calls
go directly from the app (with the API key handled via a secure proxy — see below — not embedded
in the client). If a future version needs server-side state (e.g., syncing memory across devices,
which is out of current scope), a minimal backend (Kotlin/Spring Boot or a managed
serverless function) is evaluated then, as an ADR, not built speculatively now.

**API key handling**: Gemini API calls are routed through a minimal server-side relay (even a
single serverless function) so the API key is never embedded in the shipped APK, per
`13_SECURITY.md`. This is the one piece of "backend" required from V2 onward, and it is
deliberately minimal — auth + rate limiting + forward the request.
