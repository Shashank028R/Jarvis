# V2 — Basic AI Conversation

## Purpose
Prove the core AI reasoning loop end-to-end via text input/output before adding voice or device
control complexity.

## Goals
- Text-in, text-out conversation via Gemini through a secure server-side relay.
- `AiClient` interface implemented for real (`07_AI_ARCHITECTURE.md`).
- Basic conversation session management (bounded turn history) in `:orchestrator`.

## Features
- A minimal text input UI (temporary, superseded visually by V4 but functionally retained as the
  accessibility/text-fallback surface per `03_USER_EXPERIENCE.md`).
- Coherent multi-turn conversation with reasonable context retention within a session.

## Dependencies
V1 module skeleton and DI graph.

## Architectural Changes
- Introduces the API relay service (minimal serverless function or lightweight backend) so the
  Gemini API key never ships in the client (`13_SECURITY.md`).
- `:ai` module gets its real `AiClient` implementation; `:orchestrator` gets real session state.

## New Components
- `GeminiAiClient` implementing `AiClient.converse()` only (planning/tool-calling comes later).
- API relay: a single authenticated endpoint forwarding chat requests, with basic per-user rate
  limiting.
- `ConversationSession` state holder (bounded turn window, e.g. last 10 turns).

## User Experience
User types a message, sees JARVIS's text reply, personality-consistent tone per
`03_USER_EXPERIENCE.md` (calm, concise, "Sir" default) even though voice/animation don't exist yet.

## Permissions
`INTERNET` (default-granted, declared in manifest).

## Security Considerations
- API key lives only in the relay's environment, never in the client.
- Relay authenticates the client (e.g., signed request or lightweight per-install token) to
  prevent open abuse of the relay as a free proxy.

## Testing
- Unit: `ConversationSession` turn-window bounding logic.
- Integration: `GeminiAiClient` against a fake HTTP layer (no live API calls in CI).
- Manual acceptance: a real conversation session against the live relay in a dev environment,
  checked for coherence and personality tone.

## Acceptance Criteria
- [ ] User can hold a multi-turn text conversation with contextually coherent replies.
- [ ] No API key present anywhere in the client APK (verified via a build-artifact scan).
- [ ] Relay rejects unauthenticated requests.
- [ ] Personality tone matches `03_USER_EXPERIENCE.md` in manual review.

## Known Limitations
No voice, no tool use, no device action — pure conversation only.

## Exit Criteria
All acceptance criteria met; regression test suite for V1 still passes.

## Next Version Dependencies
V3 wraps this same `AiClient.converse()` path with voice I/O; V9's planning extends
`PlannerDecision` beyond plain conversation.

---
## Phases
1. **Relay service scaffold** — deployable minimal endpoint, auth, rate limit. Tests: relay unit
   tests + a deployed staging smoke test.
2. **`AiClient` interface + Gemini implementation** — `converse()` only. Tests: fake-HTTP
   integration tests.
3. **`ConversationSession`** — bounded turn history, session lifecycle (start/end/timeout).
   Tests: unit tests on windowing and timeout logic.
4. **Text UI surface** — minimal input/output screen wired to the orchestrator.
   Tests: Compose UI test for send/receive round trip against a fake client.
5. **Personality tuning pass** — system prompt calibration against `03_USER_EXPERIENCE.md`.
   Tests: manual acceptance review against a checklist of tone criteria.
6. **Error handling** — network failure, relay auth failure, malformed response.
   Tests: failure-path unit/integration tests per `16_ERROR_HANDLING.md`.
7. **Stabilization** — full regression pass, lock version.
