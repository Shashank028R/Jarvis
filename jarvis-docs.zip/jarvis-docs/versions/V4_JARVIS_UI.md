# V4 — JARVIS UI / Activation Animation

## Purpose
Deliver the distinctive visual identity: the black-screen, red-eyes activation sequence and
minimal idle UI, synchronized to the voice state machine built in V3.

## Goals
Implement the activation animation as a pure rendering of `VoiceStateMachine` state, per
`03_USER_EXPERIENCE.md`.

## Features
- Pure black background across the app.
- Original angular red "eyes" motif rendering on activation, synchronized to the TTS greeting.
- Distinct visual treatment for Listening/Thinking/Speaking/Idle states.
- Minimal idle-state visual (reduced eye motif or subtle indicator).

## Dependencies
V3's voice state machine.

## Architectural Changes
None structural — this is a pure `:app` UI layer consuming existing `:voice` state.

## New Components
- Compose custom-drawn (Canvas/vector) eye graphics — original geometry, not a traced/rasterized
  copy of the provided reference image (see legal note in `03_USER_EXPERIENCE.md`).
- Animation timing coordinator synchronizing visual beats to TTS start/stop events.

## User Experience
Activation feels like "a futuristic AI system coming online," not a chat app opening.

## Permissions
None new.

## Security Considerations
None new; standard UI code review for performance (avoid excessive recomposition/battery cost
from animation).

## Testing
- Compose UI tests: each voice state renders its expected visual variant.
- Manual acceptance: side-by-side design review confirming originality versus the reference image
  and versus any real manufacturer's trademarked lamp design.
- Performance: animation does not cause dropped frames on the minimum-spec target device.

## Acceptance Criteria
- [ ] Activation animation plays correctly synchronized to the greeting TTS.
- [ ] Design review confirms the eye motif is an original interpretation, not a traced copy of
      the reference image or any specific real vehicle's trademarked design.
- [ ] All four voice states have a distinct, correct visual representation.
- [ ] Idle state is genuinely minimal per `03_USER_EXPERIENCE.md` ("avoid clutter").
- [ ] JARVIS's own UI meets accessibility contrast/TalkBack requirements despite the dark theme.

## Known Limitations
Purely cosmetic layer; no new functional capability.

## Exit Criteria
Acceptance criteria met; V1–V3 regression suite passes.

## Next Version Dependencies
V5's wake-word trigger enters the same state machine this UI already renders correctly.

---
## Phases
1. **Design spec finalization** — concrete original vector geometry for the eye motif, reviewed
   against the legal/originality requirement before any code is written.
2. **Static rendering** — render both-eyes-open state as a static Compose graphic.
3. **Activation sequence animation** — left-eye-then-right-eye reveal, pulse, TTS sync.
4. **State-driven visual variants** — Listening/Thinking/Speaking/Idle each get their treatment.
5. **Idle screen** — minimal persistent UI.
6. **Accessibility pass** — contrast, TalkBack labels, font scaling.
7. **Performance & stabilization** — frame-rate check on min-spec device, lock version.
